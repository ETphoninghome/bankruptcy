from flask import Flask, flash, redirect, render_template, request, session, url_for, jsonify
from json import loads
import urllib.request
from tempfile import gettempdir
from flask_session import Session
import requests
import pprint
import json

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about/')
def about():
    return render_template('about.html')
    
@app.route('/vehicle/', methods=['GET', 'POST'])
def vehicle():
    if request.method == 'POST':
            vehicle_make = request.get_json(force=True)
            response = requests.get("https://api.edmunds.com/api/vehicle/v2/{}/models?fmt=json&api_key=2skrh7ku3dkgzen67zwxcszy".format(vehicle_make)).json()
            return jsonify(response)
    else:
        return render_template('vehicle.html')
        
@app.route('/pacer/', methods=['GET', 'POST'])
def pacer():
    if request.method == "POST":
        
        if request.form["court_type"] == "" or request.form["court_region"] == "" or request.form["party_name"] == "":
            #  failure!!
            return render_template("pacer.html") 
        
        apikey = ""
        # apikey = "hyxS7CQczefd7rWy9zsu"
        court_type, court_region = request.form["court_type"], request.form["court_region"]
        filed_start_date, filed_end_date = request.form["filed_start_date"], request.form["filed_end_date"]
        closed_start_date, closed_end_date = request.form["closed_start_date"], request.form["closed_end_date"] 
        case_num, party_name = request.form["case_num"], urllib.parse.quote(request.form["party_name"])
        ssn, ssn4 = request.form["ssn"], request.form["ssn4"]
        
        url = "https://www.enclout.com/api/v1/pacer/show.json?auth_token={}".format(apikey) + "&sel_court={}".format(court_type) + "&sel_region={}".format(court_region) + "&date_filed_start={}".format(filed_start_date) + "&date_filed_end={}".format(filed_end_date) + "&date_term_start={}".format(closed_start_date) + "&date_term_end={}".format(closed_end_date) + "&case_no={}".format(case_num) + "&party={}".format(party_name) + "&ssn={}".format(ssn) + "&ssn4={}".format(ssn4)
        data = urllib.request.urlopen(url).read().decode("utf-8")
        obj = json.loads(data)
        return render_template("pacer_results.html", cart=obj["cases"])
    return render_template('pacer.html')
        
if __name__ == '__main__':
    app.run(debug=True)